create definer = root@localhost view view_kategoriegerichte_vegetarisch as
select `k`.`name`                        AS `Kategorie`,
       `e_mensa`.`gericht`.`id`          AS `ID`,
       `e_mensa`.`gericht`.`name`        AS `Gericht`,
       `e_mensa`.`gericht`.`vegetarisch` AS `vegetarisch`
from ((`e_mensa`.`gericht` left join `e_mensa`.`gericht_hat_kategorie` `ghk` on (`e_mensa`.`gericht`.`id` = `ghk`.`gericht_id`))
         left join `e_mensa`.`kategorie` `k` on (`k`.`id` = `ghk`.`Kategorie_id`))
where `e_mensa`.`gericht`.`vegetarisch` = 1;

