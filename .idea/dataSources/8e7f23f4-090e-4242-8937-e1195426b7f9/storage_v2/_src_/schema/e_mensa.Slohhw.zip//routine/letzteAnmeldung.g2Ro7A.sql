create
    definer = root@localhost procedure letzteAnmeldung(IN EMAIL varchar(100))
BEGIN
    Update benutzer Set letzteanmeldung=current_timestamp where benutzer.email=EMAIL;
END;

