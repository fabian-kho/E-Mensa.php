create definer = root@localhost view view_suppe as
select `e_mensa`.`gericht`.`id`           AS `id`,
       `e_mensa`.`gericht`.`name`         AS `name`,
       `e_mensa`.`gericht`.`beschreibung` AS `beschreibung`,
       `e_mensa`.`gericht`.`erfasst_am`   AS `erfasst_am`,
       `e_mensa`.`gericht`.`vegetarisch`  AS `vegetarisch`,
       `e_mensa`.`gericht`.`vegan`        AS `vegan`,
       `e_mensa`.`gericht`.`preis_extern` AS `preis_extern`,
       `e_mensa`.`gericht`.`preis_intern` AS `preis_intern`,
       `e_mensa`.`gericht`.`bildname`     AS `bildname`
from `e_mensa`.`gericht`
where `e_mensa`.`gericht`.`name` like '%suppe%';

