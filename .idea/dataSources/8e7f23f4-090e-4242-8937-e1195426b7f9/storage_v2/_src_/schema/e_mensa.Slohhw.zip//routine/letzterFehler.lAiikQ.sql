create
    definer = root@localhost procedure letzterFehler(IN EMAIL varchar(100))
BEGIN
    Update benutzer Set letzterfehler=current_timestamp, anzahlfehler=anzahlfehler+1 where benutzer.email=EMAIL;
END;

