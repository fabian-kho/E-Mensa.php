create definer = root@localhost view view_anmeldung as
select `b`.`anzahlanmeldungen` AS `anzahlanmeldungen`
from `e_mensa`.`benutzer` `b`
order by `b`.`anzahlanmeldungen` desc;

